﻿using System.Windows;

namespace CCD.Nback.Views
{
    /// <summary>
    /// Interaction logic for ErgebnisView.xaml
    /// </summary>
    public partial class ErgebnisView
    {
        public ErgebnisView()
        {
            InitializeComponent();
        }
    }
}
