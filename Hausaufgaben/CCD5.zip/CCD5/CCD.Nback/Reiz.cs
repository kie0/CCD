﻿namespace CCD.Nback
{
    public class Reiz
    {
        public char Buchstabe { get; set; }

        public int Index { get; set; }

        public int Total { get; set; }
    }
}