﻿namespace CCD.Nback
{
    internal class Ergebnis
    {
        public double Prozent { get; set; }
    }
}