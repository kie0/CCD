﻿namespace CCD.Nback.ViewModels
{
    public enum Reaktion
    {
        KeineAntwort,
        WiederholungErkannt,
        KeineWiederholung
    }
}